public class supermercado extends producto{
    public supermercado(String nombre, int cantidadActual, int cantidadMinima, double precio) {
        super(nombre, cantidadActual, cantidadMinima, precio);
    }
    public double iva(){
        return precio*1.04;
    }
}
