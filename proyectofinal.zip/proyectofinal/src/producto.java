public class producto {
    protected String nombre;
    protected int cantidadActual;
    protected int cantidadMinima;
    protected double precio;

    public producto(String nombre, int cantidadActual, int cantidadMinima, double precio) {
        this.nombre = nombre;
        this.cantidadActual = cantidadActual;
        this.cantidadMinima = cantidadMinima;
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public int getCantidadMinima() {
        return cantidadMinima;
    }

    public double getPrecio() {
        return precio;
    }
    public double iva(){
        return 0;
    }
    public boolean abastecer(int cantidad){
        if (cantidad>0){
            cantidadActual += cantidad;
            return true;
        }
        return false;
    }
    public boolean vender(int cantidad){
        if (cantidad>=1 && cantidad < cantidadActual){
            cantidadActual -= cantidad;
            return true ;
        }
        return false;
    }
}
