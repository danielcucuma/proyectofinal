import java.util.ArrayList;
import java.util.List;

public class tienda {
    private String nombre;
    private double dinero;
    private List<producto> productoList;

    public tienda(String nombre, double dinero, List<producto> productoList) {
        this.nombre = nombre;
        this.dinero = dinero;
        this.productoList = productoList != null ? new ArrayList<>(productoList) : new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public double getDinero() {
        return dinero;
    }

    public List<producto> getProductoList() {
        return new ArrayList<>(productoList);
    }

    public boolean agregar(producto p) {
        for (producto a : productoList) {
            if (p.equals(a)) {
                return false;
            }
        }
        productoList.add(p);
        return true;
    }

    public producto informacion(String s) {
        for (producto a : productoList) {
            if (s.equals(a.getNombre())) {
                return a;
            }
        }
        return null;
    }

    public String todos() {
        StringBuilder nombres = new StringBuilder();
        for (producto a : productoList) {
            nombres.append(a.getNombre()).append("\n");
        }
        return nombres.toString();
    }

    public double PrecioEnCaja() {
        double total = 0;
        for (producto a : productoList) {
            total += a.getPrecio();
        }
        return total;
    }

    public double abastecer(String s, int cantidad) {
        producto p = informacion(s);
        if (p != null && cantidad > 0) {
            p.abastecer(cantidad);
            return p.getPrecio() * cantidad;
        }
        return 0;
    }

    public double vender(String nombre, int cantidad) {
        producto p = informacion(nombre);
        if (p != null && p.vender(cantidad)) {
            double ingreso = p.getPrecio() * cantidad;
            dinero += ingreso;
            return ingreso;
        }
        return 0;
    }

    public boolean eliminar(String nombre) {
        producto p = informacion(nombre);
        if (p != null) {
            return productoList.remove(p);
        }
        return false;
    }

    public producto productoMasCaro() {
        if (productoList.isEmpty()) {
            return null;
        }
        producto masCaro = productoList.get(0);
        for (producto p : productoList) {
            if (p.getPrecio() > masCaro.getPrecio()) {
                masCaro = p;
            }
        }
        return masCaro;
    }

    public int cantidadProductosTipo(String tipo) {
        return 0;
    }

    public double promedioPrecioPapeleria() {
        return 0;
        }
    }

