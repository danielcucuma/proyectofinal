public class papeleria extends producto{

    public papeleria(String nombre, int cantidadActual, int cantidadMinima, double precio) {
        super(nombre, cantidadActual, cantidadMinima, precio);
    }
    @Override
    public double iva(){
        return precio*1.16;
    }
}
